<?php

class UWSMQ_Admin {

	private $current_tab;
	private $current_subtab;

	public function __construct() {
		$this->current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'settings';
		$this->current_subtab = isset( $_GET['subtab'] ) ? sanitize_text_field( $_GET['subtab'] ) : '';
		
		// Set default subtabs
		if ( empty( $this->current_subtab ) ) {
			if ( $this->current_tab === 'tools' ) {
				$this->current_subtab = 'test';
			} elseif ( $this->current_tab === 'supervisors' ) {
				$this->current_subtab = 'processing';
			}
		}
	}

	public function add_plugin_admin_menu() {
		add_options_page(
			'SMTP Mailing Queue',
			'SMTP Mailing Queue',
			'manage_options',
			'ultimate-wp-smtp-mailing-queue',
			array( $this, 'display_plugin_admin_page' )
		);
	}

	public function enqueue_styles() {
		if ( isset( $_GET['page'] ) && $_GET['page'] === 'ultimate-wp-smtp-mailing-queue' ) {
			wp_enqueue_style( 'uwsmq-admin-css', UWSMQ_PLUGIN_URL . 'admin/css/uwsmq-admin.css', array(), UWSMQ_VERSION, 'all' );
		}
	}

	public function enqueue_scripts() {
		if ( isset( $_GET['page'] ) && $_GET['page'] === 'ultimate-wp-smtp-mailing-queue' ) {
			wp_enqueue_script( 'uwsmq-admin-js', UWSMQ_PLUGIN_URL . 'admin/js/uwsmq-admin.js', array( 'jquery' ), UWSMQ_VERSION, false );
			wp_localize_script( 'uwsmq-admin-js', 'uwsmq_ajax', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'uwsmq_admin_nonce' )
			) );
		}
	}

	public function display_plugin_admin_page() {
		$tabs = array(
			'settings'    => 'SMTP Settings',
			'advanced'    => 'Advanced Settings',
			'tools'       => 'Tools',
			'supervisors' => 'Supervisors'
		);

		if ( isset( $_POST['uwsmq_save_settings'] ) && check_admin_referer( 'uwsmq_save_settings_action', 'uwsmq_save_settings_nonce' ) ) {
			$this->save_settings();
			echo '<div class="notice notice-success is-dismissible"><p>Settings saved successfully.</p></div>';
		}

		$settings = get_option( 'uwsmq_settings' );
		
		echo '<div class="wrap">';
		echo '<h1>SMTP Mailing Queue</h1>';
		
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $tab => $name ) {
			$class = ( $tab == $this->current_tab ) ? 'nav-tab-active' : '';
			echo "<a href='?page=ultimate-wp-smtp-mailing-queue&tab=$tab' class='nav-tab $class'>$name</a>";
		}
		echo '</h2>';

		echo '<div class="uwsmq-tab-content" style="margin-top: 20px;">';
		switch ( $this->current_tab ) {
			case 'advanced':
				include UWSMQ_PLUGIN_DIR . 'admin/partials/uwsmq-admin-advanced.php';
				break;
			case 'tools':
				$this->display_tools_page();
				break;
			case 'supervisors':
				$this->display_supervisors_page();
				break;
			case 'settings':
			default:
				include UWSMQ_PLUGIN_DIR . 'admin/partials/uwsmq-admin-settings.php';
				break;
		}
		echo '</div>';
		echo '</div>';
	}

	private function save_settings() {
		$old_settings = get_option( 'uwsmq_settings' );
		$new_settings = $old_settings;

		if ( $this->current_tab === 'settings' ) {
			$new_settings['smtp_host']   = sanitize_text_field( $_POST['smtp_host'] );
			$new_settings['smtp_port']   = sanitize_text_field( $_POST['smtp_port'] );
			$new_settings['smtp_auth']   = isset( $_POST['smtp_auth'] ) ? 'yes' : 'no';
			$new_settings['smtp_user']   = sanitize_text_field( $_POST['smtp_user'] );
			$new_settings['smtp_pass']   = sanitize_text_field( $_POST['smtp_pass'] );
			$new_settings['smtp_secure'] = sanitize_text_field( $_POST['smtp_secure'] );
			$new_settings['from_email']  = sanitize_email( $_POST['from_email'] );
			$new_settings['from_name']   = sanitize_text_field( $_POST['from_name'] );
		} elseif ( $this->current_tab === 'advanced' ) {
			$new_settings['enable_queue'] = isset( $_POST['enable_queue'] ) ? 'yes' : 'no';
			$new_settings['batch_size']   = (int)$_POST['batch_size'];
			$new_settings['interval']     = (int)$_POST['interval'];
			$new_settings['secret_key']    = sanitize_text_field( $_POST['secret_key'] );
			$new_settings['dont_use_wpcron'] = isset( $_POST['dont_use_wpcron'] ) ? 'yes' : 'no';
			
			if ( $old_settings['interval'] != $new_settings['interval'] || $old_settings['dont_use_wpcron'] != $new_settings['dont_use_wpcron'] ) {
				wp_clear_scheduled_hook( 'uwsmq_process_queue_cron' );
				if ( $new_settings['dont_use_wpcron'] !== 'yes' ) {
					wp_schedule_event( time(), 'uwsmq_interval', 'uwsmq_process_queue_cron' );
				}
			}
		}

		update_option( 'uwsmq_settings', $new_settings );
	}

	private function display_tools_page() {
		$subtabs = array(
			'test'    => 'Test Mail',
			'process' => 'Process Queue'
		);
		$current_subtab = $this->current_subtab;
		include UWSMQ_PLUGIN_DIR . 'admin/partials/uwsmq-admin-tools.php';
	}

	private function display_supervisors_page() {
		$subtabs = array(
			'processing' => 'Processing',
			'list'       => 'List Queue',
			'errors'     => 'Sending Errors',
			'sent'       => 'Sent'
		);
		$current_subtab = $this->current_subtab;
		
		global $wpdb;
		$table_name = $wpdb->prefix . 'uwsmq_queue';
		$items = array();
		
		if ( $current_subtab === 'list' ) {
			$items = $wpdb->get_results( "SELECT * FROM $table_name WHERE status = 'pending' ORDER BY created_at DESC" );
		} elseif ( $current_subtab === 'errors' ) {
			$items = $wpdb->get_results( "SELECT * FROM $table_name WHERE status = 'failed' ORDER BY created_at DESC" );
		} elseif ( $current_subtab === 'sent' ) {
			$items = $wpdb->get_results( "SELECT * FROM $table_name WHERE status = 'sent' ORDER BY sent_at DESC LIMIT 100" );
		}

		include UWSMQ_PLUGIN_DIR . 'admin/partials/uwsmq-admin-supervisors.php';
	}

	public function ajax_test_smtp() {
		check_ajax_referer( 'uwsmq_admin_nonce', 'nonce' );
		
		$to = sanitize_text_field( $_POST['test_email'] );
		$cc = sanitize_text_field( $_POST['test_cc'] );
		$bcc = sanitize_text_field( $_POST['test_bcc'] );
		$subject = sanitize_text_field( $_POST['test_subject'] );
		$message = wp_kses_post( $_POST['test_message'] );
		$direct = isset( $_POST['test_direct'] ) && $_POST['test_direct'] === 'true';

		$headers = array();
		if ( ! empty( $cc ) ) $headers[] = 'Cc: ' . $cc;
		if ( ! empty( $bcc ) ) $headers[] = 'Bcc: ' . $bcc;
		$headers[] = 'Content-Type: text/html; charset=UTF-8';

		$mailer = UWSMQ_Mailer::get_instance();
		
		if ( $direct ) {
			// Temporarily disable queue for this send
			add_filter( 'pre_option_uwsmq_settings', function( $val ) {
				$settings = get_option( 'uwsmq_settings' );
				$settings['enable_queue'] = 'no';
				return $settings;
			} );
		}

		$result = wp_mail( $to, $subject, $message, $headers );

		if ( $result ) {
			wp_send_json_success( array( 'message' => 'Email sent/queued successfully!' ) );
		} else {
			wp_send_json_error( array( 'message' => 'Failed to send email.' ) );
		}
	}

	public function ajax_process_queue() {
		check_ajax_referer( 'uwsmq_admin_nonce', 'nonce' );
		$mailer = UWSMQ_Mailer::get_instance();
		$mailer->process_queue();
		wp_send_json_success( array( 'message' => 'Queue processed successfully.' ) );
	}

	public function ajax_delete_item() {
		check_ajax_referer( 'uwsmq_admin_nonce', 'nonce' );
		$id = (int)$_POST['id'];
		UWSMQ_Queue::delete_item( $id );
		wp_send_json_success();
	}
}
